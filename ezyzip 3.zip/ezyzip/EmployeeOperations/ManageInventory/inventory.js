// Importing the fetchHandler module
import { fetchHandler } from "../../helper/fetchHandler.js";

(function () {
  const inventoryContainer = document.getElementById("table-container");
  const addProductBtn = document.getElementById("add-new-btn");
  const modal = document.getElementById("product-modal");
  const modalContent = document.getElementById("modal-content");
  const closeModalBtn = document.getElementById("close-productDetail-modal");
  const modalOverlay = document.getElementById("modal-overlay");
  const addProductModal = document.getElementById("add-product-modal");
  const closeAddProductModalBtn = document.getElementById(
    "close-add-product-modal"
  );
  const inventoryForm = document.getElementById("new-product-form");
  const addProductModalOverlay = document.getElementById(
    "add-product-modal-overlay"
  );

  let inventoryData; // Declare inventoryData at a higher scope

  getAdminInventory();

  ///////////////////////////////////////////////////////////////////////////////////////

  async function getAdminInventory() {
    try {
      const requestInfo = {
        url: "http://localhost:3001/api/shared/inventory/",
        method: fetchHandler.methods.get,
      };

      const data = await fetchHandler.sendRequest(requestInfo);
      inventoryData = data.data; // Store inventory data
      renderInventory(inventoryData);
    } catch (error) {
      console.error("Error fetching admin inventory:", error.message);
    }
  }

  async function addProductToInventory(category_id, productData) {
    try {
      const requestInfo = {
        url: `http://localhost:3001/api/employee/inventory/${category_id}`,
        method: fetchHandler.methods.post,
        data: productData,
      };

      const data = await fetchHandler.sendRequest(requestInfo);
      console.log("Product added successfully:", data);
    } catch (error) {
      console.error("Error adding new product:", error.message);
    }
  }

  async function deleteProduct(category_id, product_id) {
    try {
      const requestInfo = {
        url: `http://localhost:3001/api/employee/inventory/${category_id}/${product_id}`,
        method: "DELETE",
      };

      const result = await fetchHandler.sendRequest(requestInfo);
      console.log("Product deleted successfully:", result);
    } catch (error) {
      console.error("Error deleting product:", error.message);
    }
  }

  async function restockProduct(categoryID, productID) {
    try {
      const requestInfo = {
        url: `http://localhost:3001/api/employee/inventory/restock/${categoryID}/${productID}`,
        method: fetchHandler.methods.patch,
      };

      const result = await fetchHandler.sendRequest(requestInfo);
      console.log("Product restocked successfully:", result);
    } catch (error) {
      console.error("Error restocking product:", error.message);
    }
  }

  async function updateProductData(categoryID, productID, updatedData) {
    try {
      const requestInfo = {
        url: `http://localhost:3001/api/employee/inventory/${categoryID}/${productID}`,
        method: fetchHandler.methods.put,
        data: updatedData,
      };

      const data = await fetchHandler.sendRequest(requestInfo);
      console.log("Product data updated successfully:", data);
    } catch (error) {
      console.error("Error updating product data:", error.message);
    }
  }

  ///////////////////////////////////////////////////////////////////////////////////////
  function renderInventory(data) {
    inventoryContainer.innerHTML = ""; // Clear the container

    const table = document.createElement("table");

    const headerRow = document.createElement("tr");
    headerRow.innerHTML = `
      <th>Category</th>
      <th>Product ID</th>
      <th>Product Name</th>
      <th>Price</th>
      <th>Total Sold</th>
      <th>Stock</th>
      <th>Stock Status</th>
      <th>Date Added</th>
      <th>Color</th>
    `;
    table.appendChild(headerRow);

    data.forEach((category) => {
      category.products.forEach((product) => {
        const productRow = document.createElement("tr");
        productRow.innerHTML = `
          <td>${category.categoryName}</td>
          <td>${product.productID}</td>
          <td>${product.productName}</td>
          <td>$${product.unitPrice}</td>
          <td>${product.stockInfo.totalSold}</td>
          <td>${product.stockInfo.currentQuantity}</td>
          <td>${product.stockInfo.stockStatus}</td>
          <td>${product.dateAdded}</td>
          <td>${product.color}</td>
        `;

        productRow.addEventListener("click", () => {
          openProductModal(category.categoryID, product);
        });

        table.appendChild(productRow);
      });
    });

    inventoryContainer.appendChild(table);
  }

  function openProductModal(categoryID, product) {
    const formattedDateAdded = formatDate(product.dateAdded);

    modalContent.innerHTML = `
      <h2>${product.productName}</h2>
      <form id="edit-product-form">

        <label for="productId">Product ID:</label>
        <input type="text" id="productId" name="productId" value="${product.productID}" readonly>

        <label for="productName">Product Name:</label>
        <input type="text" id="productName" name="productName" value="${product.productName}" required>

        <label for="description">Description:</label>
        <textarea id="description" name="description" required>${product.productDescription}</textarea>

        <div class="multiple-input-fields">
          <div>
            <label for="price">Price:</label>
            <input type="number" id="price" name="price" value="${product.unitPrice}" required>
          </div>
          <div>
            <label for="sold">Total Sold:</label>
            <input type="number" id="sold" name="sold" value="${product.stockInfo.totalSold}" readonly>
          </div>
        </div>

        <div class="multiple-input-fields">
          <div>
            <label for="stockQuantity">Stock Quantity:</label>
            <input type="text" id="stockQuantity" name="stockQuantity" value="${product.stockInfo.currentQuantity}" readonly>
          </div>
          <div>
            <button type="button" id="restock-product-btn">Restock Product</button>
          </div>
        </div>

        <div class="multiple-input-fields">
          <div>
            <label for="restockQuantity">Restock Quantity:</label>
            <input type="number" id="restockQuantity" name="restockQuantity" value="${product.stockInfo.restockQuantity}" required>
          </div>
          <div>
            <label for="restockThreshold">Restock Threshold:</label>
            <input type="number" id="restockThreshold" name="restockThreshold" value="${product.stockInfo.restockThreshold}" required>
          </div>
        </div>

        <label for="color">Color:</label>
        <input type="text" id="color" name="color" value="${product.color}" required>

        <label for="date">Date Created:</label>
        <input type="text" id="date" name="date" value="${formattedDateAdded}" readonly>

        <div class="multiple-input-fields">
          <div>
            <button type="submit" id="save-changes-btn">Save Changes</button>
          </div>
          <div>
            <button type="button" id="delete-btn">Delete Product</button>
          </div>
        </div>

      </form>
    `;

    modal.style.display = "block";
    modalOverlay.style.display = "block";
    document.getElementById("productName").focus();

    const editProductForm = document.getElementById("edit-product-form");

    // Define the form submission handler
    async function formSubmitHandler(event) {
      event.preventDefault();

      const formData = new FormData(event.target);
      const updatedProductData = {};

      // Parse and compare form data
      const formProductName = formData.get("productName");
      if (formProductName !== product.productName) {
        updatedProductData.productName = formProductName;
      }

      const formDescription = formData.get("description");
      if (formDescription !== product.productDescription) {
        updatedProductData.productDescription = formDescription;
      }

      const formPrice = parseFloat(formData.get("price"));
      if (formPrice !== product.unitPrice) {
        updatedProductData.unitPrice = formPrice;
      }

      const formRestockQuantity = parseInt(formData.get("restockQuantity"));
      if (formRestockQuantity !== product.stockInfo.restockQuantity) {
        updatedProductData.restockQuantity = formRestockQuantity;
      }

      const formRestockThreshold = parseInt(formData.get("restockThreshold"));
      if (formRestockThreshold !== product.stockInfo.restockThreshold) {
        updatedProductData.restockThreshold = formRestockThreshold;
      }

      const formColor = formData.get("color");
      if (formColor !== product.color) {
        updatedProductData.color = formColor;
      }

      // Only send updated fields
      if (Object.keys(updatedProductData).length > 0) {
        console.log("Updating product data:", updatedProductData);
        await updateProductData(
          categoryID,
          product.productID,
          updatedProductData
        );
      }

      closeModal();
      await getAdminInventory(); // Refresh the inventory
    }

    // Remove previous event listener to prevent duplicates
    editProductForm.removeEventListener("submit", formSubmitHandler);
    editProductForm.addEventListener("submit", formSubmitHandler);

    // Restock button handler
    const restockButton = document.getElementById("restock-product-btn");
    async function restockHandler(event) {
      event.preventDefault();
      try {
        await restockProduct(categoryID, product.productID);
        closeModal();
        await getAdminInventory();
      } catch (error) {
        console.error("Error restocking product:", error.message);
      }
    }
    restockButton.removeEventListener("click", restockHandler);
    restockButton.addEventListener("click", restockHandler);

    // Delete button handler
    const deleteButton = document.getElementById("delete-btn");
    async function deleteHandler(event) {
      event.preventDefault();
      try {
        await deleteProduct(categoryID, product.productID);
        closeModal();
        await getAdminInventory();
      } catch (error) {
        console.error("Error deleting product:", error.message);
      }
    }
    deleteButton.removeEventListener("click", deleteHandler);
    deleteButton.addEventListener("click", deleteHandler);
  }

  // Close modal function
  function closeModal() {
    modal.style.display = "none";
    modalOverlay.style.display = "none";
  }

  closeModalBtn.addEventListener("click", closeModal);
  modalOverlay.addEventListener("click", closeModal);

  // Open Add new product modal
  addProductBtn.addEventListener("click", () => {
    console.log("addProductBtn:", addProductModal);
    addProductModal.style.display = "block";
    addProductModalOverlay.style.display = "block";
  });

  // Close Add Product modal
  function closeAddProductModal() {
    addProductModal.style.display = "none";
    addProductModalOverlay.style.display = "none";
  }

  closeAddProductModalBtn.addEventListener("click", closeAddProductModal);
  addProductModalOverlay.addEventListener("click", closeAddProductModal);

  function formatDate(date) {
    return new Date(date).toLocaleDateString("en-US", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
    });
  }

  // Form submission logic for adding new product
  inventoryForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    // Get data from form
    const formData = new FormData(inventoryForm);
    const categoryName = formData.get("categoryName");
    const productName = formData.get("productName");
    const productDescription = formData.get("productDescription");

    // Parse and validate numeric inputs
    const unitPrice = parseFloat(formData.get("unitPrice"));
    const stockQuantity = parseInt(formData.get("stockQuantity"));
    const restockThreshold = parseInt(formData.get("restockThreshold"));
    const restockQuantity = parseInt(formData.get("restockQuantity"));

    if (
      isNaN(unitPrice) ||
      isNaN(stockQuantity) ||
      isNaN(restockThreshold) ||
      isNaN(restockQuantity)
    ) {
      alert("Please enter valid numbers for price and stock quantities.");
      return;
    }

    const imageFile = formData.get("imageUrl");
    const imageUrl = imageFile ? imageFile.name : "";
    const color = formData.get("color");
    const dateAdded = new Date().toISOString();

    const productData = {
      categoryName: categoryName,
      product: {
        productName: productName,
        productDescription: productDescription,
        unitPrice: unitPrice,
        stockInfo: {
          currentQuantity: stockQuantity,
          totalSold: 0,
          restockThreshold: restockThreshold,
          lastRestock: dateAdded,
          restockQuantity: restockQuantity,
          stockStatus: stockQuantity > 0 ? "In Stock" : "Out of Stock",
        },
        imageUrl: imageUrl,
        dateAdded: dateAdded,
        color: color,
      },
    };

    // Find the Category ID for the selected category
    const categoryData = inventoryData.find(
      (data) => data.categoryName === categoryName
    );
    const category_id = categoryData.categoryID;

    await addProductToInventory(category_id, productData);
    closeAddProductModal();
    getAdminInventory(); // Refresh the inventory
  });
})();
