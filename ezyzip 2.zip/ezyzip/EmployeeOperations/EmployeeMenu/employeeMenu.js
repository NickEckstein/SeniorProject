// This module loads all the employee operation contents dynamically

// Importing modules
import { loader } from "../../helper/loadPageDynamically.js";

// Toggle Button
const hamBurger = document.querySelector(".toggle-btn");

// This is the main container where external content is loaded
const contentArea = document.getElementById("outer-main-container");

// These are the buttons
const reportLoader = document.getElementById("report-loader");
const employeeLoader = document.getElementById("employee-loader");
const customerLoader = document.getElementById("customer-loader");
const inventoryLoader = document.getElementById("inventory-loader");

// This is the sidebar
const sideBar = document.querySelector("#sidebar");

// The logout button
const logoutBtn = document.getElementById("logout-btn");

// Logic for expanding the menu
hamBurger.addEventListener("click", function () {
  sideBar.classList.toggle("expand");
});

// Load the reports when the window loads
window.onload = () => {
  console.log("Hi");
  loadReports();
};

// Load reports when the report button is pressed
reportLoader.addEventListener("click", () => {
  loadReports();
  closeSideBar();
});

// Load the employee page
employeeLoader.addEventListener("click", () => {
  loadPageWithFade({
    htmlUrl: "../ManageEmployees/employees.html",
    cssUrl: "../employee_functions.css",
    jsUrl: "../ManageEmployees/employees.js",
  });
  closeSideBar();
});

// Load the customer page
customerLoader.addEventListener("click", () => {
  loadPageWithFade({
    htmlUrl: "../ManageCustomers/customer.html",
    cssUrl: "../employee_functions.css",
    jsUrl: "../ManageCustomers/customer.js",
  });
  closeSideBar();
});

// Load the inventory page
inventoryLoader.addEventListener("click", () => {
  loadPageWithFade({
    htmlUrl: "../ManageInventory/inventory.html",
    cssUrl: "../employee_functions.css",
    jsUrl: "../ManageInventory/inventory.js",
  });
  closeSideBar();
});

// Logout button functionality
logoutBtn.addEventListener("click", () => {
  sessionStorage.clear();
  window.location.href = "../../Login/login.html";
});

// *Helper Methods

// Load reports
function loadReports() {
  try {
    // Apply fade-out effect, load the content, then fade-in
    applyFadeEffect(() => {
      loader.removeJs();
      loader.removeCss();
      loader.loadCSS("../Reports/reports.css", contentArea);
      loader.loadHTML("../Reports/reports.html", contentArea);
    });
  } catch (error) {
    console.error("Error loading reports:", error);
  }
}

// Function to load page with fade effects
function loadPageWithFade({ htmlUrl, cssUrl, jsUrl }) {
  try {
    applyFadeEffect(() => {
      loader.removeJs();
      loader.removeCss();
      loader.loadPageContent({
        htmlUrl,
        cssUrl,
        jsUrl,
        targetElement: contentArea,
      });
    });
  } catch (error) {
    console.error("Error loading page:", error);
  }
}

// Apply fade-out, load content, then fade-in
function applyFadeEffect(loadFunction, callback) {
  // Add fade-out class to initiate fade-out transition
  contentArea.classList.add("fade-out");

  // Event handler for when fade-out transition ends
  function onFadeOutEnd(event) {
    if (event.target !== contentArea || event.propertyName !== "opacity")
      return;
    contentArea.removeEventListener("transitionend", onFadeOutEnd);

    // Load new content if loadFunction is provided
    if (typeof loadFunction === "function") {
      loadFunction();
    }

    // Remove fade-out class and add fade-in class to initiate fade-in transition
    contentArea.classList.remove("fade-out");
    contentArea.classList.add("fade-in");

    // Listen for fade-in transition end to clean up
    contentArea.addEventListener("transitionend", onFadeInEnd);
  }

  // Event handler for when fade-in transition ends
  function onFadeInEnd(event) {
    if (event.target !== contentArea || event.propertyName !== "opacity")
      return;
    contentArea.removeEventListener("transitionend", onFadeInEnd);

    // Remove fade-in class
    contentArea.classList.remove("fade-in");

    // Call the callback function if provided
    if (typeof callback === "function") {
      callback();
    }
  }

  // Listen for fade-out transition end
  contentArea.addEventListener("transitionend", onFadeOutEnd);
}

// Close the sidebar
function closeSideBar() {
  sideBar.classList.remove("expand");
}
