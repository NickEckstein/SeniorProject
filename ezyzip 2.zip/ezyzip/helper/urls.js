// This module has all the urls
const HOSTNAME = "http://localhost:3001/api";
export const urlObject = {
  employeeLogin: HOSTNAME + "/employee/login",
  customerLogin: HOSTNAME + "/customer/login",
  inventoryReport: HOSTNAME + "/employee/inventory/report",
  salesReport: HOSTNAME + "/employee/sale/report",
  createCustomer: HOSTNAME + "/shared/customer",
  getCustomerList: HOSTNAME + "employee/customer",
};
